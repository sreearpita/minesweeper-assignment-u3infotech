package com.u3info.minesweeper;

public class Main {
    public static void main(String[] args) {

        MinesweepAppController app = new MinesweepAppController();
        app.run(System.in, System.out);

    }
}
